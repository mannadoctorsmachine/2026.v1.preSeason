package frc.robot.lib.motors;

/**
 * Representa o comportamento do motor quando nenhuma tensao e aplicada (ponto morto).
 */
public enum NeutralMode {
  COAST,
  BRAKE
}
