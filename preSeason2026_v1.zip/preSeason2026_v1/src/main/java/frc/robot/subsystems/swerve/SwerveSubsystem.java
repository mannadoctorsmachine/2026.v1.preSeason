package frc.robot.subsystems.swerve;

import static frc.robot.subsystems.swerve.SwerveConstants.*;

import edu.wpi.first.math.MathUtil;
import edu.wpi.first.math.geometry.Pose2d;
import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.math.kinematics.ChassisSpeeds;
import edu.wpi.first.math.kinematics.SwerveDriveKinematics;
import edu.wpi.first.math.kinematics.SwerveModulePosition;
import edu.wpi.first.math.kinematics.SwerveModuleState;
import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.SubsystemBase;
import frc.robot.RobotState;
import frc.robot.lib.navigation.AllianceUtil;
import frc.robot.lib.sensors.Gyro;
import frc.robot.lib.sensors.GyroInputs;
import frc.robot.lib.sensors.SensorFactory;
import frc.robot.lib.sensors.SimulatedGyro;
import java.util.function.DoubleSupplier;
import org.littletonrobotics.junction.Logger;

/**
 * Subsistema do swerve: cuida APENAS de cinematica e motores.
 * Nao sabe nada de visao: so envia odometria (rodas + gyro) para o {@link RobotState}, que e quem
 * mantem a pose do robo no campo.
 */
public class SwerveSubsystem extends SubsystemBase {
  private final SwerveModule[] modules;
  private final SwerveDriveKinematics kinematics;
  private final Gyro gyro;
  private final GyroInputs gyroInputs = new GyroInputs();
  private final RobotState robotState;

  private ChassisSpeeds measuredSpeeds = new ChassisSpeeds();
  private Rotation2d fallbackYaw = Rotation2d.kZero;
  private double lastTimestamp = Timer.getFPGATimestamp();

  public SwerveSubsystem(RobotState robotState, SwerveDriveKinematics kinematics) {
    this.robotState = robotState;
    this.kinematics = kinematics;
    this.modules =
        new SwerveModule[] {
          new SwerveModule(kFrontLeft),
          new SwerveModule(kFrontRight),
          new SwerveModule(kBackLeft),
          new SwerveModule(kBackRight)
        };
    this.gyro = SensorFactory.createGyro(kGyroType, kGyroCanId, kCanBus);

    gyro.updateInputs(gyroInputs);
    fallbackYaw = new Rotation2d(gyroInputs.yawRadians);
    robotState.resetPose(Pose2d.kZero, fallbackYaw, getModulePositions());
  }

  /** Cinematica do swerve a partir das constantes (para criar o {@link RobotState}). */
  public static SwerveDriveKinematics createKinematics() {
    return new SwerveDriveKinematics(
        kFrontLeft.location(), kFrontRight.location(), kBackLeft.location(), kBackRight.location());
  }

  @Override
  public void periodic() {
    double now = Timer.getFPGATimestamp();
    double dt = Math.max(now - lastTimestamp, 1e-3);
    lastTimestamp = now;

    for (SwerveModule module : modules) {
      module.periodic();
    }
    measuredSpeeds = kinematics.toChassisSpeeds(getModuleStates());

    // Gyro (em simulacao a velocidade angular vem da cinematica das rodas)
    if (gyro instanceof SimulatedGyro simGyro) {
      simGyro.setYawVelocityRadPerSec(measuredSpeeds.omegaRadiansPerSecond);
    }
    gyro.updateInputs(gyroInputs);
    Logger.processInputs("Swerve/Gyro", gyroInputs);

    // Se o gyro cair, estima a rotacao pela cinematica das rodas
    Rotation2d yaw;
    if (gyroInputs.connected) {
      yaw = new Rotation2d(gyroInputs.yawRadians);
      fallbackYaw = yaw;
    } else {
      fallbackYaw = fallbackYaw.plus(new Rotation2d(measuredSpeeds.omegaRadiansPerSecond * dt));
      yaw = fallbackYaw;
    }

    robotState.setRobotRelativeVelocity(measuredSpeeds);
    robotState.addOdometryObservation(now, yaw, getModulePositions());

    if (DriverStation.isDisabled()) {
      for (SwerveModule module : modules) {
        module.stop();
      }
      Logger.recordOutput("Swerve/SetpointStates", new SwerveModuleState[] {});
    }

    Logger.recordOutput("Swerve/MeasuredStates", getModuleStates());
    Logger.recordOutput("Swerve/MeasuredSpeeds", measuredSpeeds);
    Logger.recordOutput("Swerve/GyroConnected", gyroInputs.connected);
  }

  // ---------------------------------------------------------------------------------------------
  // Comandos de movimento
  // ---------------------------------------------------------------------------------------------

  /** Move o robo com velocidades no referencial do ROBO. */
  public void runVelocity(ChassisSpeeds robotRelativeSpeeds) {
    ChassisSpeeds discretized = ChassisSpeeds.discretize(robotRelativeSpeeds, 0.02);
    SwerveModuleState[] states = kinematics.toSwerveModuleStates(discretized);
    SwerveDriveKinematics.desaturateWheelSpeeds(states, kMaxSpeedMps);
    SwerveModuleState[] optimized = new SwerveModuleState[modules.length];
    for (int i = 0; i < modules.length; i++) {
      optimized[i] = modules[i].setDesiredState(states[i]);
    }
    Logger.recordOutput("Swerve/SetpointSpeeds", discretized);
    Logger.recordOutput("Swerve/SetpointStates", states);
    Logger.recordOutput("Swerve/OptimizedStates", optimized);
  }

  /** Move o robo com velocidades no referencial do CAMPO (frente do campo = +X). */
  public void runFieldVelocity(ChassisSpeeds fieldRelativeSpeeds) {
    runVelocity(ChassisSpeeds.fromFieldRelativeSpeeds(fieldRelativeSpeeds, getHeading()));
  }

  public void stop() {
    runVelocity(new ChassisSpeeds());
  }

  /** Posiciona as rodas em "X" para o robo nao ser empurrado. */
  public void lockWheels() {
    ModuleConfig[] configs = {kFrontLeft, kFrontRight, kBackLeft, kBackRight};
    for (int i = 0; i < modules.length; i++) {
      // Roda tangente ao circulo que passa pelos modulos => formato de "X"
      Rotation2d angle = configs[i].location().getAngle().plus(Rotation2d.kCCW_Pi_2);
      modules[i].setDesiredState(new SwerveModuleState(0.0, angle));
    }
  }

  /**
   * Comando de teleoperacao: joystick -> velocidades no referencial do campo.
   * @param xSupplier Frente/tras (-1..1, +1 = frente).
   * @param ySupplier Esquerda/direita (-1..1, +1 = esquerda).
   * @param omegaSupplier Rotacao (-1..1, +1 = anti-horario).
   */
  public Command driveCommand(
      DoubleSupplier xSupplier, DoubleSupplier ySupplier, DoubleSupplier omegaSupplier) {
    return run(
        () -> {
          double x = MathUtil.applyDeadband(xSupplier.getAsDouble(), 0.08);
          double y = MathUtil.applyDeadband(ySupplier.getAsDouble(), 0.08);
          double omega = MathUtil.applyDeadband(omegaSupplier.getAsDouble(), 0.08);
          // Curva quadratica para mais precisao em baixa velocidade
          x = Math.copySign(x * x, x);
          y = Math.copySign(y * y, y);
          omega = Math.copySign(omega * omega, omega);
          // Na alianca vermelha o operador olha para o outro lado: "frente" = -X do campo
          double allianceSign = AllianceUtil.isRed() ? -1.0 : 1.0;
          runFieldVelocity(
              new ChassisSpeeds(
                  allianceSign * x * kMaxSpeedMps,
                  allianceSign * y * kMaxSpeedMps,
                  omega * kMaxAngularSpeedRadPerSec));
        });
  }

  // ---------------------------------------------------------------------------------------------
  // Leituras
  // ---------------------------------------------------------------------------------------------

  public SwerveModuleState[] getModuleStates() {
    SwerveModuleState[] states = new SwerveModuleState[modules.length];
    for (int i = 0; i < modules.length; i++) {
      states[i] = modules[i].getState();
    }
    return states;
  }

  public SwerveModulePosition[] getModulePositions() {
    SwerveModulePosition[] positions = new SwerveModulePosition[modules.length];
    for (int i = 0; i < modules.length; i++) {
      positions[i] = modules[i].getPosition();
    }
    return positions;
  }

  /** @return Velocidade medida do chassi (referencial do robo). */
  public ChassisSpeeds getChassisSpeeds() {
    return measuredSpeeds;
  }

  public Pose2d getPose() {
    return robotState.getPose();
  }

  public Rotation2d getHeading() {
    return robotState.getHeading();
  }

  public RobotState getRobotState() {
    return robotState;
  }

  /**
   * Define a frente atual do robo como "para longe do operador" (0 graus na alianca azul, 180 na
   * vermelha), mantendo a posicao X/Y.
   */
  public void zeroHeading() {
    Pose2d pose = robotState.getPose();
    Rotation2d forward = AllianceUtil.isRed() ? Rotation2d.kPi : Rotation2d.kZero;
    robotState.resetPose(new Pose2d(pose.getTranslation(), forward));
  }

  public void setBrakeMode(boolean brake) {
    for (SwerveModule module : modules) {
      module.setBrakeMode(brake);
    }
  }
}
