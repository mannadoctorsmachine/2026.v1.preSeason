package frc.robot.subsystems.swerve;

import static frc.robot.subsystems.swerve.SwerveConstants.*;

import edu.wpi.first.math.MathUtil;
import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.math.kinematics.SwerveModulePosition;
import edu.wpi.first.math.kinematics.SwerveModuleState;
import edu.wpi.first.wpilibj.RobotBase;
import frc.robot.lib.motors.MotorConfig;
import frc.robot.lib.motors.MotorController;
import frc.robot.lib.motors.MotorFactory;
import frc.robot.lib.motors.MotorInputs;
import frc.robot.lib.motors.MotorType;
import frc.robot.lib.motors.NeutralMode;
import frc.robot.lib.sensors.AbsoluteEncoder;
import frc.robot.lib.sensors.AbsoluteEncoderConfig;
import frc.robot.lib.sensors.AbsoluteEncoderInputs;
import frc.robot.lib.sensors.SensorFactory;
import org.littletonrobotics.junction.Logger;

/**
 * Um modulo swerve: 1 motor de tracao + 1 motor de esterco + 1 encoder absoluto.
 * Usa exclusivamente as interfaces das libs de motores e sensores (nenhum codigo de fabricante aqui).
 *
 * <p>Premissa: o encoder absoluto mede o eixo de esterco 1:1 (como nos modulos SDS/REV/Thrifty).
 */
public class SwerveModule {
  private static final double kWheelCircumference = 2.0 * Math.PI * kWheelRadiusMeters;

  private final String name;
  private final MotorController drive;
  private final MotorController steer;
  private final AbsoluteEncoder encoder;

  private final MotorInputs driveInputs = new MotorInputs();
  private final MotorInputs steerInputs = new MotorInputs();
  private final AbsoluteEncoderInputs encoderInputs = new AbsoluteEncoderInputs();

  private boolean steerSeeded = false;

  public SwerveModule(ModuleConfig config) {
    this.name = config.name();
    boolean sim = RobotBase.isSimulation();

    MotorConfig driveConfig =
        new MotorConfig()
            .withInverted(config.driveInverted())
            .withNeutralMode(NeutralMode.BRAKE)
            .withGearRatio(kDriveGearRatio)
            .withStatorCurrentLimit(kDriveStatorCurrentLimitAmps)
            .withSupplyCurrentLimit(kDriveSupplyCurrentLimitAmps)
            .withPID(kDriveKp, 0.0, 0.0, kDriveKs, kDriveKv, 0.0);

    MotorConfig steerConfig =
        new MotorConfig()
            .withInverted(config.steerInverted())
            .withNeutralMode(NeutralMode.BRAKE)
            .withGearRatio(kSteerGearRatio)
            .withStatorCurrentLimit(kSteerStatorCurrentLimitAmps)
            .withPID(kSteerKp, 0.0, kSteerKd);

    drive =
        MotorFactory.create(
            config.driveId(), kCanBus, sim ? MotorType.SIMULATED : kDriveMotorType, driveConfig);
    steer =
        MotorFactory.create(
            config.steerId(), kCanBus, sim ? MotorType.SIMULATED : kSteerMotorType, steerConfig);

    encoder =
        SensorFactory.createAbsoluteEncoder(
            kEncoderType,
            config.encoderId(),
            kCanBus,
            new AbsoluteEncoderConfig().withOffset(config.encoderOffsetRotations()).withRange(-0.5));

    // Primeira leitura (o CANcoder pode demorar alguns ciclos; o periodic() tenta de novo)
    periodic();
  }

  /** Deve ser chamado exatamente uma vez por ciclo (atualiza telemetria e, em sim, a fisica). */
  public void periodic() {
    drive.updateInputs(driveInputs);
    steer.updateInputs(steerInputs);
    encoder.updateInputs(encoderInputs);
    Logger.processInputs("Swerve/" + name + "/Drive", driveInputs);
    Logger.processInputs("Swerve/" + name + "/Steer", steerInputs);
    Logger.processInputs("Swerve/" + name + "/Encoder", encoderInputs);

    // Sincroniza o encoder interno do esterco com o absoluto assim que ele estiver disponivel
    if (!steerSeeded && encoderInputs.connected) {
      steer.setEncoderPosition(encoderInputs.positionRotations);
      steerInputs.positionRotations = encoderInputs.positionRotations;
      steerSeeded = true;
    }
  }

  /**
   * Comanda o modulo. Otimiza para nunca girar mais de 90 graus e usa o caminho mais curto.
   * @return Estado efetivamente comandado.
   */
  public SwerveModuleState setDesiredState(SwerveModuleState desired) {
    Rotation2d currentAngle = getAngle();
    SwerveModuleState state = new SwerveModuleState(desired.speedMetersPerSecond, desired.angle);
    state.optimize(currentAngle);
    state.cosineScale(currentAngle); // reduz a velocidade enquanto a roda ainda esta girando

    // Alvo do esterco no mesmo "volta" do encoder interno (evita giros desnecessarios)
    double current = steerInputs.positionRotations;
    double delta = MathUtil.inputModulus(state.angle.getRotations() - current, -0.5, 0.5);
    steer.setPosition(current + delta);

    drive.setVelocity(state.speedMetersPerSecond / kWheelCircumference);
    return state;
  }

  public void stop() {
    drive.stop();
    steer.stop();
  }

  public void setBrakeMode(boolean brake) {
    drive.setBrakeMode(brake);
    steer.setBrakeMode(brake);
  }

  public Rotation2d getAngle() {
    return Rotation2d.fromRotations(steerInputs.positionRotations);
  }

  public SwerveModuleState getState() {
    return new SwerveModuleState(
        driveInputs.velocityRotationsPerSec * kWheelCircumference, getAngle());
  }

  public SwerveModulePosition getPosition() {
    return new SwerveModulePosition(
        driveInputs.positionRotations * kWheelCircumference, getAngle());
  }

  public String getName() {
    return name;
  }

  /** @return true se o encoder absoluto respondeu e o esterco foi sincronizado. */
  public boolean isSeeded() {
    return steerSeeded;
  }
}
