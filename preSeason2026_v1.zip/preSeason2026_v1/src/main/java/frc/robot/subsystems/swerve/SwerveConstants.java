package frc.robot.subsystems.swerve;

import edu.wpi.first.math.geometry.Translation2d;
import edu.wpi.first.math.util.Units;
import frc.robot.lib.motors.MotorType;
import frc.robot.lib.sensors.SensorFactory.AbsoluteEncoderType;
import frc.robot.lib.sensors.SensorFactory.GyroType;

/**
 * Constantes do swerve.
 * ATENCAO: todos os valores marcados com TODO sao PLACEHOLDERS e precisam ser medidos/ajustados
 * no robo real (IDs CAN, offsets dos encoders, dimensoes, ganhos).
 */
public final class SwerveConstants {
  private SwerveConstants() {}

  // --- Geometria (TODO: medir) ---
  public static final double kTrackWidthMeters = Units.inchesToMeters(24.0); // esquerda-direita
  public static final double kWheelBaseMeters = Units.inchesToMeters(24.0); // frente-tras
  public static final double kWheelRadiusMeters = Units.inchesToMeters(2.0);

  // --- Limites (TODO: ajustar ao robo) ---
  public static final double kMaxSpeedMps = 4.5;
  public static final double kMaxAngularSpeedRadPerSec = Math.PI * 2.0;

  // --- Reducoes (Rotacoes do motor / rotacoes do mecanismo) (TODO: conferir modulo) ---
  public static final double kDriveGearRatio = 6.12; // ex: SDS MK4i L3
  public static final double kSteerGearRatio = 150.0 / 7.0; // ex: SDS MK4i

  // --- Hardware (TODO) ---
  public static final String kCanBus = ""; // "" = RIO ; ou nome do CANivore
  public static final MotorType kDriveMotorType = MotorType.TALON_FX;
  public static final MotorType kSteerMotorType = MotorType.TALON_FX;
  public static final AbsoluteEncoderType kEncoderType = AbsoluteEncoderType.CANCODER;
  public static final GyroType kGyroType = GyroType.PIGEON2;
  public static final int kGyroCanId = 13;

  // --- Limites de corrente ---
  public static final double kDriveStatorCurrentLimitAmps = 80.0;
  public static final double kDriveSupplyCurrentLimitAmps = 40.0;
  public static final double kSteerStatorCurrentLimitAmps = 40.0;

  // --- Ganhos (TODO: ajustar no robo) ---
  // Drive: velocidade em rot/s da roda. kV ~ 12V / (velocidade livre da roda em rps)
  public static final double kDriveKp = 0.3;
  public static final double kDriveKs = 0.1;
  public static final double kDriveKv = 0.73;
  // Steer: posicao em rotacoes do modulo
  public static final double kSteerKp = 50.0;
  public static final double kSteerKd = 0.5;

  /**
   * Configuracao individual de um modulo.
   * @param encoderOffsetRotations Leitura absoluta do encoder (rotacoes) com a roda apontando para
   *     frente (TODO: medir em cada modulo).
   * @param location Posicao do modulo em relacao ao centro do robo (x = frente, y = esquerda).
   */
  public record ModuleConfig(
      String name,
      int driveId,
      int steerId,
      int encoderId,
      double encoderOffsetRotations,
      boolean driveInverted,
      boolean steerInverted,
      Translation2d location) {}

  private static final double kHalfTrack = kTrackWidthMeters / 2.0;
  private static final double kHalfBase = kWheelBaseMeters / 2.0;

  // TODO: IDs CAN e offsets reais
  public static final ModuleConfig kFrontLeft =
      new ModuleConfig("FL", 1, 2, 3, 0.0, false, true, new Translation2d(kHalfBase, kHalfTrack));
  public static final ModuleConfig kFrontRight =
      new ModuleConfig("FR", 4, 5, 6, 0.0, false, true, new Translation2d(kHalfBase, -kHalfTrack));
  public static final ModuleConfig kBackLeft =
      new ModuleConfig("BL", 7, 8, 9, 0.0, false, true, new Translation2d(-kHalfBase, kHalfTrack));
  public static final ModuleConfig kBackRight =
      new ModuleConfig("BR", 10, 11, 12, 0.0, false, true, new Translation2d(-kHalfBase, -kHalfTrack));

  // --- PathPlanner (TODO: medir/pesar o robo) ---
  public static final double kRobotMassKg = 50.0;
  public static final double kRobotMoiKgM2 = 6.0; // momento de inercia (estimar no CAD)
  public static final double kWheelCoefficientOfFriction = 1.2; // ex: tapete de roda tipico
  public static final int kDriveMotorsPerModule = 1;
  public static final double kAutoTranslationKp = 5.0;
  public static final double kAutoRotationKp = 5.0;

  /** Raio do circulo que envolve o robo (centro ate o canto do chassi), sem folga. */
  public static final double kRobotCircumradiusMeters = Math.hypot(kHalfBase, kHalfTrack) + 0.10;
}
