package frc.robot.auto;

import static frc.robot.subsystems.swerve.SwerveConstants.*;

import com.pathplanner.lib.auto.AutoBuilder;
import com.pathplanner.lib.config.ModuleConfig;
import com.pathplanner.lib.config.PIDConstants;
import com.pathplanner.lib.config.RobotConfig;
import com.pathplanner.lib.controllers.PPHolonomicDriveController;
import com.pathplanner.lib.util.PathPlannerLogging;
import edu.wpi.first.math.geometry.Pose2d;
import edu.wpi.first.math.system.plant.DCMotor;
import frc.robot.RobotState;
import frc.robot.lib.navigation.AllianceUtil;
import frc.robot.subsystems.swerve.SwerveSubsystem;
import org.littletonrobotics.junction.Logger;

/**
 * Configura o PathPlanner uma unica vez. O PathPlanner so enxerga duas coisas do robo: a pose
 * (do {@link RobotState}) e o drivetrain (comando de velocidade do {@link SwerveSubsystem}).
 */
public final class PathPlannerSetup {
  private PathPlannerSetup() {
    throw new UnsupportedOperationException("Classe utilitaria!");
  }

  public static void configure(SwerveSubsystem swerve, RobotState robotState) {
    // Configuracao do robo montada em codigo (nao depende do arquivo settings.json da GUI)
    ModuleConfig moduleConfig =
        new ModuleConfig(
            kWheelRadiusMeters,
            kMaxSpeedMps,
            kWheelCoefficientOfFriction,
            DCMotor.getKrakenX60(kDriveMotorsPerModule),
            kDriveGearRatio,
            kDriveSupplyCurrentLimitAmps,
            kDriveMotorsPerModule);

    RobotConfig robotConfig =
        new RobotConfig(
            kRobotMassKg,
            kRobotMoiKgM2,
            moduleConfig,
            kFrontLeft.location(),
            kFrontRight.location(),
            kBackLeft.location(),
            kBackRight.location());

    AutoBuilder.configure(
        robotState::getPose,
        robotState::resetPose,
        swerve::getChassisSpeeds,
        (speeds, feedforwards) -> swerve.runVelocity(speeds),
        new PPHolonomicDriveController(
            new PIDConstants(kAutoTranslationKp, 0.0, 0.0),
            new PIDConstants(kAutoRotationKp, 0.0, 0.0)),
        robotConfig,
        AllianceUtil::isRed, // espelha trajetorias (desenhadas no lado azul) para a alianca vermelha
        swerve);

    // Telemetria das trajetorias no log
    PathPlannerLogging.setLogActivePathCallback(
        poses -> Logger.recordOutput("Auto/ActivePath", poses.toArray(new Pose2d[0])));
    PathPlannerLogging.setLogTargetPoseCallback(pose -> Logger.recordOutput("Auto/TargetPose", pose));
  }
}
