// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package frc.robot;

import edu.wpi.first.wpilibj.RobotBase;

/**
 * The Constants class provides a convenient place for teams to hold robot-wide numerical or boolean
 * constants. This class should not be used for any other purpose. All constants should be declared
 * globally (i.e. public static). Do not put anything functional in this class.
 *
 * <p>It is advised to statically import this class (or one of its inner classes) wherever the
 * constants are needed, to reduce verbosity.
 */
public final class Constants {
  /** Modo de execucao do codigo, usado para configurar o AdvantageKit. */
  public enum Mode {
    /** Rodando no robo real. */
    REAL,
    /** Rodando em simulacao no computador. */
    SIM,
    /** Reprocessando um log (replay) no computador. */
    REPLAY
  }

  /** Mude para {@link Mode#REPLAY} para reexecutar um arquivo de log no simulador. */
  private static final Mode kSimMode = Mode.SIM;

  public static final Mode kCurrentMode = RobotBase.isReal() ? Mode.REAL : kSimMode;

  public static class OperatorConstants {
    public static final int kDriverControllerPort = 0;
  }
}
